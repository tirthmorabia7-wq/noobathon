const mongoose = require('mongoose');

const StateSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    cash: { type: Number, default: 0 },
    heat: { type: Number, default: 0 },
    wantedLevel: { type: Number, default: 0 },
    totalOpsRun: { type: Number, default: 0 },
    missionWins: { type: Number, default: 0 },
    missionFails: { type: Number, default: 0 },
    missionActive: { type: Number, default: 0 },
    lastLocation: { type: String, default: 'Vinewood Hills' },
    recentHits: [{
        name: String,
        location: String,
        time: Date,
        coords: [Number]
    }],
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('State', StateSchema);
